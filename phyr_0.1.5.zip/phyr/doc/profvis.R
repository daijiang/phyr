## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "##",
  eval = F
)

## ----data_prep-----------------------------------------------------------
#  library(profvis)
#  library(dplyr, quietly = T)
#  library(phyr)
#  comm = comm_a
#  comm$site = row.names(comm)
#  dat = tidyr::gather(comm, key = "sp", value = "freq", -site) %>%
#    left_join(envi, by = "site") %>%
#    left_join(traits, by = "sp")
#  dat$pa = as.numeric(dat$freq > 0)
#  tree = phylotree

## ----prof1---------------------------------------------------------------
#  profvis({
#    phyr::communityPGLMM(freq ~ 1 + shade + (1|sp__) + (1|site) + (1|sp@site), dat,
#                         tree = phylotree, REML = T, cpp = F, optimizer = "bobyqa")
#  })

## ----prof2---------------------------------------------------------------
#  profvis({
#    phyr::communityPGLMM(freq ~ 1 + shade + (1|sp__) + (1|site) + (1|sp@site), dat,
#                         tree = phylotree, REML = T, cpp = T, optimizer = "bobyqa")
#  })

## ----prof3---------------------------------------------------------------
#  profvis({
#    phyr::communityPGLMM(freq ~ 1 + shade + (1|sp__) + (1|site) + (1|sp@site), dat,
#                         tree = phylotree, REML = T, cpp = F, optimizer = "Nelder-Mead")
#  })

## ----prof4---------------------------------------------------------------
#  profvis({
#    phyr::communityPGLMM(freq ~ 1 + shade + (1|sp__) + (1|site) + (1|sp@site), dat,
#                         tree = phylotree, REML = T, cpp = T, optimizer = "Nelder-Mead")
#  })

## ----prof5---------------------------------------------------------------
#  profvis({
#    phyr::communityPGLMM(pa ~ 1 + shade + (1|sp__) + (1|site) + (1|sp@site), dat,
#                         family = "binomial", tree = phylotree, REML = T, cpp = F,
#                         optimizer = "bobyqa")
#  })

## ----prof6---------------------------------------------------------------
#  profvis({
#    phyr::communityPGLMM(pa ~ 1 + shade + (1|sp__) + (1|site) + (1|sp@site), dat,
#                         family = "binomial", tree = phylotree, REML = T, cpp = T,
#                         optimizer = "bobyqa")
#  })

## ----prof7---------------------------------------------------------------
#  profvis({
#    phyr::communityPGLMM(pa ~ 1 + shade + (1|sp__) + (1|site) + (1|sp@site), dat,
#                         family = "binomial", tree = phylotree, REML = T, cpp = F,
#                         optimizer = "Nelder-Mead")
#  })

## ----prof8---------------------------------------------------------------
#  profvis({
#    phyr::communityPGLMM(pa ~ 1 + shade + (1|sp__) + (1|site) + (1|sp@site), dat,
#                         family = "binomial", tree = phylotree, REML = T, cpp = T,
#                         optimizer = "Nelder-Mead")
#  })

## ----prof9---------------------------------------------------------------
#  profvis({
#    psv(comm_sim, tree_sim, cpp = FALSE)
#  })

## ----prof10--------------------------------------------------------------
#  profvis({
#    x <- psv(comm_sim, tree_sim, cpp = TRUE)
#  })
#  
#  microbenchmark::microbenchmark(psv(comm, tree, cpp = FALSE),
#                                 psv(comm, tree, cpp = TRUE), times = 100)
#  
#  microbenchmark::microbenchmark(pse(comm, tree, cpp = FALSE),
#                                 pse(comm, tree, cpp = TRUE), times = 100)

## ----prof11--------------------------------------------------------------
#  phy = ape::rtree(n = 10000)
#  profvis({
#    ape::vcv(phy, corr = T)
#  })
#  profvis({
#    vcv2(phy, corr = T)
#  })

